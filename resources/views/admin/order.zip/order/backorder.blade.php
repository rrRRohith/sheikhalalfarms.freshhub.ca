@extends('layouts.admin')
@section('title','Backorder')
@section('page_title','Sales & Financials')
@section('page_nav')
<ul>
    <li><a href="{{admin_url('orders')}}">All Orders</a></li>
    <li><a  href="{{admin_url('invoices')}}">Invoices</a>
    <li class="active"><a  href="{{admin_url('backorders')}}">Backorders</a></li>
    
</ul>
@endsection
@section('contents')
<div class="content-container">
   <div class="content-area">
      <div class="row main_content">
         <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="card no-margin minH">
               <div class="card-block">
                    <div class="headercnt_top">
                            <div class="innerpage_title">
                                        <h3>Backorders</h3>
                                    </div>
                        <div class="clearfix"></div>
                    </div>
                   <section class="card-text customers_outer">
                     <div class="row filter-customer">
                           <div class="col-lg-12">
                              <div class="filter-customer-list">
                                 @if (Session::has('message'))
                                 <div class="alert alert-success">
                                    <font color="red" size="4px">{{ Session::get('message') }}</font>
                                 </div>
                                 @endif
                                <div class="table-list-responsive-md">
                                    <table class="table table-customer mt-0">
                                       <thead>
                                          <tr>
                                             
                                             <th class="text-center">
                                                Date
                                             </th>
                                             <th class="text-center">
                                                PO No
                                             </th>
                                             <th class="text-right">
                                                Amount
                                             </th>
                                             <th class="text-right">Actions</th>
                                             
                                            
                                          </tr>
                                         </thead>
                                         <tbody>
                                          @if(isset($orders) && count($orders)>0)
                                          @foreach($orders as $order)
                                          <tr>
                                             
                                             <td class="text-center">
                                                {{date('d M Y',strtotime($order->order_date))}}
                                             </td>
                                             <td class="text-center">
                                                PO{{$order->id}}
                                             </td>
                                             
                                             <td class="text-right" style="text-align:right;">
                                               ${{$order->grand_total}}
                                             </td>
                                             <td>
                                                 <div class="fh_actions">
                                                    <a href="#" class="fh_link">Actions <i class="fa fa-caret-down"></i> </a>
                                                    <ul class="fh_dropdown">
                                                        <li><a href="{{admin_url('backorders')}}/{{$order->id}}">View Backorder</a></li>
                                                        <!--<li><a href="{{admin_url('backorders')}}/placeorder/{{$order->id}}">Place Order</a></li>-->
                                                    </ul>
                                                 </div> 
                                             </td>
                                             
                                             
                                            
                                          </tr>
                                           
                                          @endforeach
                                          @else
                                        
                                          <tr>
                                              <td colspan="4"><center>Sorry No Backorders Found</center></td>
                                          </tr>
                                          @endif
                                    
                                       
                                         
                                       </tbody>
                                    </table>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </section>
                  
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
@endsection