  @extends('layouts.master')
       @section('contents')
  <div class="content-container">
        <div class="content-area">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 no-xs-padding">
                    <div class="card no-margin minH">
                        <div class="card-block">
                            <div class="card-title">
                                <div class="card-title-header">
                                    <div class="card-title-header-titr"><b> Customers </b></div>
                                    <div class="card-title-header-between"></div>
                                    <div class="card-title-header-actions">
                                       
                                        <a href="#"><img src="http://admin.freshhub.ca/img/help.svg" alt="help"
                                                         class="card-title-header-img card-title-header-details"></a>
                                    </div>
                                </div>
                            </div>
                            <section class="card-text">
                                                                                                    <section class="card-text">
    <div class="row filter-customer">
        
        <filter-panel
             :filter-columns='[{"text":"Account Name","value":"Account__account_name"},{"text":"Account Brand","value":"Account__account_brand"},{"text":"Account Email","value":"Account__account_email"},{"text":"Account Phone","value":"Account__account_phone"},{"text":"Account Province","value":"Account__account_province"},{"text":"City","value":"Account__account_city"},{"text":"Account Address","value":"Account__account_address"},{"text":"National ID","value":"Account__account_national_id"},{"text":"Economic Identifier","value":"Account__account_economic_identifier"},{"text":"Website","value":"Account__account_website"},{"text":"Industry","value":"Account__account_scope"},{"text":"Technician","value":"Account__technician_id"},{"text":"Account created at","value":"Account__Account__created_at"},{"text":"Source Title","value":"OpportunitySource__opportunity_source"},{"text":"Customer Note Created Date","value":"CustomerNote__CustomerNote__created_at"},{"text":"Customer Note Type","value":"CustomerNote__note_type_id"},{"text":"Customer Source","value":"Opportunity__opportunity_status"},{"text":"Total Invoice","value":"Invoice__invoice_total"},{"text":"Customer Color Badge","value":"CustomerColorBadge__customer_color_badge_name"}]'
            :filters-list="[]"
            :date-fields='[{"value" : "NoteType__NoteType__created_at"},{"value" : "CustomerNote__CustomerNote__created_at"},{"value" : "Ticket__ticket_end_date"},{"value" : "Ticket__ticket_start_date"},{"value" : "User__User__created_at"},{"value": "Account__Account__created_at"}]'
            :collapse="false">
</filter-panel>

        <div class="col-lg-9">
            <div class="filter-customer-list">
                <a class="toggle-filter-customer left "
                   href="#">
                </a>
                @if (Session::has('message'))
                <div class="alert alert-success">
                    <font color="red" size="4px">{{ Session::get('message') }}</font>
                </div>
            @endif
                <div class="table-list-responsive-md">
                    <table class="table table-list mt-0">

                    <thead class="table-list-header-options">
                    <tr>
                        <td colspan="5">
                            <form id="search_form" action="http://admin.freshhub.ca/accounts/search" method="get">
                                <div class="input-group input-group-icon input-group-table">
                                        <span class="input-group-prepend" id="basic-addon1">
                                            <clr-icon shape="search" size="20"></clr-icon>
                                        </span>
                                    <input type="search" class="form-control input-light"
                                           placeholder="Search ..."
                                           name="search_text"
                                           value=""
                                           aria-describedby="basic-addon1">
                                </div>
                            </form>
                        </td>
                       <td colspan="5">
                                                        <a href="{{url('admin/customers/create')}}"
                               class="btn btn-success pull-right">
                                <clr-icon shape="plus-circle"></clr-icon>
                                New Customer                            </a>
                                                        <div class="btn-group pull-right mr-0">
                                <div class="btn-group-overflow">
                                    <button class="btn dropdown-toggle btn-success-outline pull-right">
                                        <clr-icon shape="angle down"></clr-icon>
                                        Actions                                    </button>
                                    <div class="dropdown-menu">

                                                                                <a class="btn" href="http://admin.freshhub.ca/accounts/importaccounts">
                                            Import Accounts From File                                        </a>
                                        
                                        <button class="btn" data-target=".js-field-customization"
                                                data-toggle="modal">
                                            Customize Columns                                        </button>


                                        <form action="http://admin.freshhub.ca/accounts/export_excel" method="post" class="pt-0">
                                            <input type="hidden" name="url" value="/accounts">
                                            <input type="hidden" name="search_text" value="">
                                            <button type="submit" class="btn">Export Excel</button>
                                        </form>

                                                                                <span class="dropdown-divider"></span>
                                        <button id="delete-content"
                                                class="btn js-bulk-action"
                                                data-method="DELETE"
                                                data-description="If you delete the account, the contact(s) in the subset will also be erased. Do you have continue?"
                                                data-title="Delete"
                                                data-action="">
                                            Delete                                        </button>
                                                                            </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                    </thead>

                    <thead>

                    <tr>
                        <th>
                            <div class="checkbox">
                                <input type="checkbox" id="checkrads" class="chk-select-all">
                                <label for="checkrads"></label>
                            </div>
                        </th>                                                                                                  <th >
                                        Name
                                    </th>                                                                               
                                    <th>
                                        Email
                                    </th>
                                    <th>                                                                           
                                        Address
                                    </th>
                                     <th>                                                               
                                        City
                                    </th>
                                    <th>                                                               
                                        Country
                                    </th>
                                    <th>                
                                        Phone
                                    </th>
                                   
                                    <th>Actions</th>
                        
                    </tr>
                    </thead>
                    <tbody>
                        @foreach($customer as $c)
                    <tr  >         <td>
                                    <div class="checkbox">
                                        <input type="checkbox" id="checkrads_2"
                                               value="2">
                                        <label for="checkrads_2"></label>
                                    </div>
                                </td>
                                <td class="text-lg-left  text-md-left"data-label='Organization'><label class=""><a target='' href='http://admin.freshhub.ca/customers/{{$c->id}}'>{{$c->firstname}}{{$c->lastname}}</a></label></td>
                                <td data-label='Email'><label class="">{{$c->email}}</label></td>
                                <td data-label='City'><label class="">{{$c->address}}</label></td>
                                <td data-label='Account Province'><label class="">{{$c->city}}</label></td>
                                <td data-label='Account Province'><label class="">{{$c->country}}</label></td>
                                
                                <td data-label='Phone'><phone phone-range="{{$c->phone}}" type-num="phone"></phone></td>                
                               
                <td data-label=Actions><label>
                                        <a target="" href="http://admin.freshhub.ca/opportunities/create?account_id=2" class="icon-table" rel="tooltip" data-tooltip=" Create Opportunity">
                                            <img src="http://admin.freshhub.ca/img/convert-opportunity.svg" alt="convert" width="22">
                                        </a>
                                    </label><label>
                                        <a target="" href="http://admin.freshhub.ca/accounts/2/edit" class="icon-table" rel="tooltip" data-tooltip=" Edit">
                                            <clr-icon shape="pencil" size="22"></clr-icon>
                                        </a>
                                    </label></td>
                                </tr>
                                @endforeach
                                    

                    </tbody>
                    <tfoot>
                    <tr>
                        <th colspan="5">
                            <nav class="pull-left number" aria-label="Page navigation">
                                                                    

                                                            </nav>
                        </th>
                        <th colspan="5"
                            class="text-lg-right text-md-right number">
                            Show                            2 case                            from 2
                            Customer                        </th>
                    </tr>
                    </tfoot>
                </table>
                </div>
            </div>
        </div>
    </div>
    </section>
        <div class="modal js-field-customization">
    <div class="modal-dialog" role="dialog" aria-hidden="true">
        <div class="modal-content">
            <form class="" method="POST" action="http://admin.freshhub.ca/accounts/datatablearrangement">
                <input name="module_name" type="hidden" value="accounts">
                <input name="moduleID" id="moduleID" type="hidden" value="1">
                <input type="hidden" name="" value="">
                <div class="modal-header">
                    <button aria-label="Close" class="close" type="button" onClick="cancelModal()">
                        <clr-icon aria-hidden="true" shape="close"></clr-icon>
                    </button>
                    <h3 class="modal-title">Customize Columns</h3>
                </div>
                <div class="modal-body  modal-middle-y ui-sortable">
                                                                        <div id="" class="row ui-sortable-handle">
                                <clr-icon shape="drag-handle" size="32"></clr-icon>
                                <div class="col-lg-1 col-md-1 col-sm-1 col-xs-2">
                                    <div class="checkbox">
                                        <input name="account_name"
                                               checked
                                                type="checkbox"
                                               value="1"
                                               id="fields__1">
                                        <label for="fields__1"></label>
                                    </div>
                                </div>
                                <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10">
                                        <label>Organization</label>
                                        
                                </div>
                            </div>
                                                    <div id="" class="row ui-sortable-handle">
                                <clr-icon shape="drag-handle" size="32"></clr-icon>
                                <div class="col-lg-1 col-md-1 col-sm-1 col-xs-2">
                                    <div class="checkbox">
                                        <input name="account_national_id"
                                               
                                                type="checkbox"
                                               value="1"
                                               id="fields__2">
                                        <label for="fields__2"></label>
                                    </div>
                                </div>
                                <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10">
                                        <label>National ID</label>
                                        
                                </div>
                            </div>
                                                    <div id="" class="row ui-sortable-handle">
                                <clr-icon shape="drag-handle" size="32"></clr-icon>
                                <div class="col-lg-1 col-md-1 col-sm-1 col-xs-2">
                                    <div class="checkbox">
                                        <input name="account_email"
                                               checked
                                                type="checkbox"
                                               value="1"
                                               id="fields__3">
                                        <label for="fields__3"></label>
                                    </div>
                                </div>
                                <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10">
                                        <label>Email</label>
                                        
                                </div>
                            </div>
                                                    <div id="" class="row ui-sortable-handle">
                                <clr-icon shape="drag-handle" size="32"></clr-icon>
                                <div class="col-lg-1 col-md-1 col-sm-1 col-xs-2">
                                    <div class="checkbox">
                                        <input name="account_website"
                                               
                                                type="checkbox"
                                               value="1"
                                               id="fields__4">
                                        <label for="fields__4"></label>
                                    </div>
                                </div>
                                <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10">
                                        <label>Website</label>
                                        
                                </div>
                            </div>
                                                    <div id="" class="row ui-sortable-handle">
                                <clr-icon shape="drag-handle" size="32"></clr-icon>
                                <div class="col-lg-1 col-md-1 col-sm-1 col-xs-2">
                                    <div class="checkbox">
                                        <input name="account_economic_identifier"
                                               
                                                type="checkbox"
                                               value="1"
                                               id="fields__5">
                                        <label for="fields__5"></label>
                                    </div>
                                </div>
                                <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10">
                                        <label>Economic Identifier</label>
                                        
                                </div>
                            </div>
                                                    <div id="" class="row ui-sortable-handle">
                                <clr-icon shape="drag-handle" size="32"></clr-icon>
                                <div class="col-lg-1 col-md-1 col-sm-1 col-xs-2">
                                    <div class="checkbox">
                                        <input name="account_city"
                                               checked
                                                type="checkbox"
                                               value="1"
                                               id="fields__6">
                                        <label for="fields__6"></label>
                                    </div>
                                </div>
                                <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10">
                                        <label>City</label>
                                        
                                </div>
                            </div>
                                                    <div id="" class="row ui-sortable-handle">
                                <clr-icon shape="drag-handle" size="32"></clr-icon>
                                <div class="col-lg-1 col-md-1 col-sm-1 col-xs-2">
                                    <div class="checkbox">
                                        <input name="account_province"
                                               checked
                                                type="checkbox"
                                               value="1"
                                               id="fields__7">
                                        <label for="fields__7"></label>
                                    </div>
                                </div>
                                <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10">
                                        <label>Account Province</label>
                                        
                                </div>
                            </div>
                                                    <div id="" class="row ui-sortable-handle">
                                <clr-icon shape="drag-handle" size="32"></clr-icon>
                                <div class="col-lg-1 col-md-1 col-sm-1 col-xs-2">
                                    <div class="checkbox">
                                        <input name="account_address"
                                               
                                                type="checkbox"
                                               value="1"
                                               id="fields__8">
                                        <label for="fields__8"></label>
                                    </div>
                                </div>
                                <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10">
                                        <label>Account Address</label>
                                        
                                </div>
                            </div>
                                                    <div id="" class="row ui-sortable-handle">
                                <clr-icon shape="drag-handle" size="32"></clr-icon>
                                <div class="col-lg-1 col-md-1 col-sm-1 col-xs-2">
                                    <div class="checkbox">
                                        <input name="account_brand"
                                               checked
                                                type="checkbox"
                                               value="1"
                                               id="fields__9">
                                        <label for="fields__9"></label>
                                    </div>
                                </div>
                                <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10">
                                        <label>Brand</label>
                                        
                                </div>
                            </div>
                                                    <div id="" class="row ui-sortable-handle">
                                <clr-icon shape="drag-handle" size="32"></clr-icon>
                                <div class="col-lg-1 col-md-1 col-sm-1 col-xs-2">
                                    <div class="checkbox">
                                        <input name="account_phone"
                                               checked
                                                type="checkbox"
                                               value="1"
                                               id="fields__10">
                                        <label for="fields__10"></label>
                                    </div>
                                </div>
                                <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10">
                                        <label>Phone</label>
                                        
                                </div>
                            </div>
                                                    <div id="" class="row ui-sortable-handle">
                                <clr-icon shape="drag-handle" size="32"></clr-icon>
                                <div class="col-lg-1 col-md-1 col-sm-1 col-xs-2">
                                    <div class="checkbox">
                                        <input name="account_scope"
                                               
                                                type="checkbox"
                                               value="1"
                                               id="fields__11">
                                        <label for="fields__11"></label>
                                    </div>
                                </div>
                                <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10">
                                        <label>Industry</label>
                                        
                                </div>
                            </div>
                                                    <div id="" class="row ui-sortable-handle">
                                <clr-icon shape="drag-handle" size="32"></clr-icon>
                                <div class="col-lg-1 col-md-1 col-sm-1 col-xs-2">
                                    <div class="checkbox">
                                        <input name="technician_id"
                                               
                                                type="checkbox"
                                               value="1"
                                               id="fields__33">
                                        <label for="fields__33"></label>
                                    </div>
                                </div>
                                <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10">
                                        <label>Technician</label>
                                        
                                </div>
                            </div>
                                                    <div id="" class="row ui-sortable-handle">
                                <clr-icon shape="drag-handle" size="32"></clr-icon>
                                <div class="col-lg-1 col-md-1 col-sm-1 col-xs-2">
                                    <div class="checkbox">
                                        <input name="opportunity_source"
                                               
                                                type="checkbox"
                                               value="1"
                                               id="fields__35">
                                        <label for="fields__35"></label>
                                    </div>
                                </div>
                                <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10">
                                        <label>Source Title</label>
                                        
                                </div>
                            </div>
                                                            </div>

                <div class="modal-footer">
                    <div class="col-lg-4 col-md-5 col-sm-12">
                        <button class="btn btn-success btn-block" type="submit" onClick="submitModal()">
                            <clr-icon shape="floppy"></clr-icon>
                            Save                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
                            </section>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
    @endsection