@extends('layouts.master')
       @section('contents')
<div class="content-container">
        <div class="content-area">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 no-xs-padding">
                    <div class="card no-margin minH">
                        <div class="card-block">
                            <div class="card-title">
                                <div class="card-title-header">
                                    <div class="card-title-header-titr"><b> Add Customer </b></div>
                                    <div class="card-title-header-between"></div>
                                    <div class="card-title-header-actions">
                                                                                                                                                                
                                                                                                                                                                
                                        

                                        


                                                                                    <a href="{{url('admin/customers')}}"
                                               class="btn btn-success-outline-x btn-icon card-title-header-details" rel="tooltip"
                                               data-tooltip="Back">
                                                <clr-icon shape="undo" class="is-solid"></clr-icon>
                                            </a>
                                        
                                        <a href="#"><img src="http://admin.freshhub.ca/img/help.svg" alt="help"
                                                         class="card-title-header-img card-title-header-details"></a>
                                    </div>
                                </div>
                            </div>
                            <section class="card-text">
                                                                                                   <!--  <div class="form-group row">
        <div class="toggle-switch toggle-switch-two-way">
            <input value='0' name="contact_status" type="checkbox"
                  checked   id="switchCustomerFormMode">
            <label for="switchCustomerFormMode">Contact</label>
            <label for="switchCustomerFormMode">Account</label>
        </div>
    </div> -->

    <div class="px-lg-3 " id="addAccountForm">
        <form class="pt-0" id="form" method="post"
              action="{{url('admin/customers')}}">
            @csrf
            <section class="form-block">
                <div class="separator">
                    <label class="separator-text separator-text-success">Customer Details</label>
                </div>
                <div class="form-group row">
                    <div class="col-lg-1 col-md-1 col-sm-12 col-xs-12 text-right no-md-padding">
                        <label class="text-gray-dark"
                               for="account_name">First Name*</label>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-12">
                        <input class="form-control" id="firstname"
                               value="{{old('firstname')}}"
                               name="firstname">
                               @if ($errors->has('firstname'))
                                <strong>{{ $errors->first('firstname') }}</strong>
                            @endif
                    </div>
                    <div class="col-lg-1 col-md-1 col-sm-12 col-xs-12 text-right no-md-padding">
                        <label class="text-gray-dark"
                               for="company_brand">Last Name</label>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-12">
                        <input class="form-control" id="lastname"
                               value="{{old('lastname')}}"
                               name="lastname">
                               @if ($errors->has('lastname'))
                                <strong>{{ $errors->first('lastname') }}</strong>
                            @endif
                    </div>
                    <div class="col-lg-1 col-md-1 col-sm-12 col-xs-12 text-right no-md-padding">
                        <label class="text-gray-dark"
                               for="account_email">Email</label>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-12">
                        <input class="form-control" name="email"
                               value="{{old('email')}}"
                               id="email">
                               @if ($errors->has('email'))
                                <strong>{{ $errors->first('email') }}</strong>
                            @endif
                    </div>
                </div>
                <div class="form-group row">
                   <div class="col-lg-1 col-md-1 col-sm-12 col-xs-12 text-right no-md-padding">
                        <label class="text-gray-dark"
                               for="account_address">Address</label>
                    </div>
                    <div class="col-lg-7 col-md-7 col-sm-12">
                        <input class="form-control" id="address"
                               value="{{old('address')}}"
                               name="address">
                               @if ($errors->has('address'))
                                <strong>{{ $errors->first('address') }}</strong>
                            @endif
                    </div>
                    
                    <div class="col-lg-1 col-md-1 col-sm-12 col-xs-12 text-right no-md-padding">
                        <label class="text-gray-dark"
                               for="account_economic_identifier">Postal Code</label>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-12">
                        <input class="form-control number" id="postalcode"
                               value="{{old('postalcode')}}"
                               name="postalcode">
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-lg-1 col-md-1 col-sm-12 col-xs-12 text-right no-md-padding">
                        <label class="text-gray-dark"
                               for="account_phone">Phone</label>
                        <popover class-name="popover-lg">
                            Enter all phone number that customer places in your regin or province without any zero code,<br> But enter phone number that customers places outside of your regin or province with zero code.<br> Enter phone numbers without dash (-) sign and just use this to set range of phone numbers like ex:33225566-9 or ex:33225568-72 or ex:02833225568-72                        </popover>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-12">
                        <phone-input-mask id="phone" name="phone"
                               value="{{old('phone')}}">
                        </phone-input-mask>
                        @if ($errors->has('phone'))
                                <strong>{{ $errors->first('phone') }}</strong>
                            @endif
                    </div>
                    <div class="col-lg-1 col-md-1 col-sm-12 col-xs-12 text-right no-md-padding">
                        <label class="text-gray-dark"
                               for="account_province">Province</label>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-12">
                        <input class="form-control" id="province"
                               value="{{old('province')}}"
                               name="province">
                        
                         @if ($errors->has('province'))
                                <strong>{{ $errors->first('province') }}</strong>
                            @endif 
                        
                        
                        
                    </div>
                    <div class="col-lg-1 col-md-1 col-sm-12 col-xs-12 text-right no-md-padding">
                        <label class="text-gray-dark"
                               for="account_city">City</label>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-12">
                        <input class="form-control" name="city"
                               value="{{old('city')}}"
                               id="city">
                        
                        
                        
                        
                        
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-lg-1 col-md-1 col-sm-12 col-xs-12 text-right no-md-padding">
                        <label class="text-gray-dark"
                               for="account_national_id">Country</label>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-12">
                        <input class="form-control number" id="country"
                               value="{{old('country')}}"
                               name="country">
                               @if ($errors->has('country'))
                                <strong>{{ $errors->first('country') }}</strong>
                            @endif 
                    </div>
                    
                    <div class="col-lg-1 col-md-1 col-sm-12 col-xs-12 text-right no-md-padding">
                        <label class="text-gray-dark"
                               for="opportunity_source_id"> Type</label>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-12">
                        <select name="customer" id="customer" class="form-control ">
                          <option value="customer">Customer</option>

                        </select>
                    </div>
                    <div class="col-lg-1 col-md-1 col-sm-12 col-xs-12 text-right no-md-padding">
                        <label class="text-gray-dark"
                               for="opportunity_source_id"> Profile Picture</label>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-12">
                        <input type="file" class="form-control" id="profile_picture" name="profile_picture">
                    </div>
                </div>
                <div class="form-group row">
                    
                    <div class="col-lg-1 col-md-1 col-sm-12 col-xs-12 text-right no-md-padding">
                        <label class="text-gray-dark"
                               for="opportunity_source_id"> User Name</label>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-12">
                        <input class="form-control number" id="username"
                               value="{{old('username')}}"
                               name="username">
                               @if ($errors->has('username'))
                                <strong>{{ $errors->first('username') }}</strong>
                            @endif
                    </div>
                    <div class="col-lg-1 col-md-1 col-sm-12 col-xs-12 text-right no-md-padding">
                        <label class="text-gray-dark"
                               for="opportunity_source_id"> Password</label>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-12">
                        <input class="form-control number" id="password"
                               value=""
                               name="password">
                               @if ($errors->has('password'))
                                <strong>{{ $errors->first('password') }}</strong>
                            @endif
                    </div>
                    
                    
                </div>
                
                
                
                
                
                
                
                
                
                
                
                
                
            </section>
           
            <section>
                <div class="form-group row">
                    <div class="offset-lg-1 col-lg-3 col-sm-4 col-xs-6">
                        <button type="submit"
                                class="btn btn-success btn-block">
                            <clr-icon
                                    shape="floppy"></clr-icon> Save                        </button>
                    </div>
                </div>
            </section>
        </form>
    </div>
                            </section>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
@endsection