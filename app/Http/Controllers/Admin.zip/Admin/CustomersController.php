<?php

namespace App\Http\Controllers\Admin;

//use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\CustomerRequest;
use Illuminate\Support\Facades\Hash;
use App\User;

class CustomersController extends Controller
{

    public function index()
    {
        $customer = User::where('customer','customer')->get();
        $title="Customers";
        return view('admin.customers',compact('customer'),compact('title'));
    }


    public function create()
    {
        //$roles =  Category::orderBy('name','ASC')->get();
         $title="Customers";
        return view('admin.customersadd',compact('title'));
    }


    public function store(CustomerRequest $request)
    {
        $user = new User();
        
        $user->firstname     = $request->firstname;
        $user->lastname      = $request->lastname;
        $user->username      = $request->username;
        $user->password      = Hash::make($request->password);
        $user->email         = $request->email;
        $user->phone         = $request->phone;
        $user->address       = $request->address;
        $user->city          = $request->city;
        $user->postalcode    = $request->postalcode;
        $user->province      = $request->province;
        $user->country       = $request->country;
        $user->customer      = $request->customer;
        // print_r($user);
        // die;
        
       
        
        if($request->hasFile('profile_picture') && $request->file('profile_picture')->isValid())
        {
            $filename = str_random(40).'.'.$request->profile_picture->extension();
            $request->profile_picture->storeAs('media/customers',$filename);
            $user->profile_picture = $filename;
        }
        
        try {
            
            $user->save();
            // session()->flash('message','<div class="alert alert-success">Successfully created the category</div>');
            session()->flash('message','Successfully created the customer');
        }
        catch(\Exception $e) {
            session()->flash('message','Unable to create the customer. Please try again.');
        }
        
        return redirect('admin/customers');
        
    }

    public function show($id)
    {
        // LATER
    }

    public function edit($id)
    {
        $categories = Category::orderBy('created_at','DESC')->get();
        $category = Category::find($id) or abort(404);
        return view('admin.category-form',compact('category'),compact('categories'));
    }

    public function update(CategoryRequest $request, $id)
    {
        $category = Category::find($id) or abort(404);
        
        $category->name             = $request->name;
        $category->description      = $request->description;
        $category->slug             = ($request->name);
        $category->parent_id        = $request->parent_id;
        $category->display_order    = $request->display_order;
        $category->featured         = $request->has('featured');
        $category->published        = $request->has('published');
        
        if($request->hasFile('picture') && $request->file('picture')->isValid())
        {
            
            $filename = str_random(40).'.'.$request->picture->extension();
            $request->picture->storeAs('media/categories',$filename);
            @unlink('media/categories/'.$category->picture);
            $category->picture = $filename;
        }
        
        try {
            
            $category->save();
            session()->flash('message','Successfully updated the category');
        }
        catch(\Exception $e) {
            session()->flash('message','Unable to update the category. Please try again.');
        }
        
        return redirect('/categories');
    }
        
    public function destroy($id)
    {
        $category = Category::find($id) or abort(404);
        @unlink('media/'.$category->picture);
       
        try {
            $category->delete();
            session()->flash('message','Category successfully deleted');
        }
        catch(\Exception $e) {
            session()->flash('message','Unable to delete the category');
        }
        
        return redirect('categories');
    }
}
